package com.future.rule;

/**
 * @author Cock-a-doodle-doo!
 */
public enum HiveLogicOperator {
    /*&&*/
    and,
    /*||*/
    or,
    /* !*/
    not,
}
